![logo](https://raw.githubusercontent.com/mr-sami-x/SQLi/main/Picsart_23-07-21_02-11-16-006.png)

# MDX-SQLi
It is a tool for scanning and exploiting the famous SQL injection vulnerability in more than millions of sites. The exploit was programmed by the 1555 team.

### programming language : 
```Python3.11.0```

### operating commands :
1- ```cd SQLi```

2- ```python3 sqli.py ```

## Watch a video explanation of the tool through this video
[Video link here](http://)
## Follow us on our accounts on social networking sites

1- [Telegram](https://t.me/team_1555)
2- [Instagram](https://instagram.com/i4m.mdx)
3- [Snapchat](https://www.snapchat.com/add/i4m.mdx)
4- [YouTube](https://www.youtube.com/@i4m.mdx)
